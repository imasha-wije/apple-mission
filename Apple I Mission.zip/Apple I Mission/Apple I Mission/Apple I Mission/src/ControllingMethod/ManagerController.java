
package ControllingMethod;

import Database.DatabaseConnection;


public class ManagerController {
    
    
    
    
    
    
    
    public void addProduct(String id,String name,String category,String quantity,String price){
        DatabaseConnection d1=new DatabaseConnection();
        d1.addProduct(id, name, category, quantity, price);
        
    }
    
}
