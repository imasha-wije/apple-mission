
package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DatabaseConnection {
   
    
    
    public void addProduct(String id,String name,String category,String quantity,String price){
        System.out.println(id);
          System.out.println(name);
            System.out.println(category);
              System.out.println(quantity);
                System.out.println(price);
                
    }
}

