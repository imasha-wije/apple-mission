
package Model;


public class Product {
    
}
